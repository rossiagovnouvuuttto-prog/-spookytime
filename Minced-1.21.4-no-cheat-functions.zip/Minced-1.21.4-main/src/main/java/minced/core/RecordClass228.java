package minced.core;

public final class RecordClass228 {
    public final String label;
    public final String icon;
    public final int iconColor;

    public RecordClass228(String label, String icon, int iconColor) {
        this.label = label;
        this.icon = icon;
        this.iconColor = iconColor;
    }

    public String label() { return label; }
    public String icon() { return icon; }
    public int iconColor() { return iconColor; }
}
