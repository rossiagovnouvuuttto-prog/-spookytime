/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 */
package minced.core;

import minced.core.CancellableEvent;
import minced.core.EventBase;

public class EventPostTick
extends EventBase
implements CancellableEvent {
}

