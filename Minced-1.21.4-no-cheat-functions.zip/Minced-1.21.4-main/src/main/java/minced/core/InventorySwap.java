package minced.core;

/** Moves an inventory item from its current slot to the requested slot. */
public record InventorySwap(int sourceSlot, int targetSlot) {
}
