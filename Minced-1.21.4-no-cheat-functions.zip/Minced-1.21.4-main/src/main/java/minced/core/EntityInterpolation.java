/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 */
package minced.core;

public interface EntityInterpolation {
    public double getPrevServerY();

    public double getServerX();

    public double getServerY();

    public boolean method3306();

    public void setServerPos(double var1, double var3, double var5);

    public double getPrevServerX();

    public double getServerZ();

    public double getPrevServerZ();

    public void method3307(boolean var1);
}



