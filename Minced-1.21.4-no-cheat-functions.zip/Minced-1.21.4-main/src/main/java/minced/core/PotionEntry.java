/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 */
package minced.core;

import java.util.function.Function;
import minced.core.Animation;
import minced.core.Easings;

class PotionEntry
{
    static long field7975 = 200L;
    Animation field7976 = new Animation(Easings.field11952, 0.0f, field7975);
    static long field7977 = 44L;
    Animation field7978 = new Animation(Easings.field11952, 0.0f, field7977);

    public PotionEntry() {
    }
}

