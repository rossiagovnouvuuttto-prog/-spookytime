/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 */
package minced.core;

public interface CancellableEvent {
    default public boolean method2297() { return false; }

    default public void method2298(boolean var1) {}
}

