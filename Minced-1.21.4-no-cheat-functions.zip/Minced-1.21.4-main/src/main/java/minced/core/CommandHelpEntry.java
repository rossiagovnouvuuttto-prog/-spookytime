package minced.core;

/** A single row displayed by the help command. */
public record CommandHelpEntry(
        String command,
        String[] arguments,
        BracketStyle brackets,
        String description
) {
    public CommandHelpEntry(String command, String[] arguments, BracketStyle brackets) {
        this(command, arguments, brackets, null);
    }

    public enum BracketStyle {
        PARENTHESES("(", ")"),
        SQUARE("[", "]"),
        ANGLE("<", ">");

        private final String opening;
        private final String closing;

        BracketStyle(String opening, String closing) {
            this.opening = opening;
            this.closing = closing;
        }

        public String opening() {
            return opening;
        }

        public String closing() {
            return closing;
        }
    }
}
