/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 * 
 * Could not load the following classes:
 *  net.minecraft.entity.ai.TargetPredicate$EntityPredicate
 */
package minced.core;

class RectEntry
 {
    float field11737;
    float field11738;
    float field11739;
    float field11740;
    int field11741;

    RectEntry(float param1, float param2, float param3, float param4, int param5) {
        this.field11737 = param1;
        this.field11738 = param2;
        this.field11739 = param3;
        this.field11740 = param4;
        this.field11741 = param5;
    }
}

