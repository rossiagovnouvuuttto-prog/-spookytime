/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 * 
 * Could not load the following classes:
 *  net.minecraft.client.MinecraftClient
 *  org.lwjgl.opengl.GL11C
 *  org.lwjgl.system.MemoryStack
 */
package minced.core;

import java.awt.Rectangle;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import minced.render.ImmediateRenderer;
import net.minecraft.client.gui.ScreenRect;

public class ScissorUtil
implements Predicate {
    static List field9137;
    static List field9138;
    static Rectangle field9139;

    public static void method2620() {
        if (!field9138.isEmpty()) {
            field9139 = (Rectangle)field9138.remove(field9138.size() - 1);
        } else {
            field9139 = null;
        }
        ScissorUtil.applyDeferredScissor(field9139);
    }

    public static void method2621(double param0, double param2, double param4, double param6) {
        field9138.add(field9139 == null ? null : new Rectangle(field9139));
        Rectangle v21 = new Rectangle(
            (int)Math.floor(param0),
            (int)Math.floor(param2),
            Math.max(0, (int)Math.ceil(param4)),
            Math.max(0, (int)Math.ceil(param6))
        );
        Rectangle v23 = field9139;
        Rectangle v24 = v23 == null ? v21 : ScissorUtil.method2623(v21, v23);
        if (v24.width < 0) {
            v24.width = 0;
        }
        if (v24.height < 0) {
            v24.height = 0;
        }
        field9139 = new Rectangle(v24);
        ScissorUtil.applyDeferredScissor(field9139);
    }

    public static void method2622() {
        field9138 = new ArrayList();
        field9139 = null;
        field9137 = new ArrayList();
    }

    private static Rectangle method2623(Rectangle param0, Rectangle param1) {
        if (param0 == null || param1 == null) {
            return new Rectangle(0, 0, 0, 0);
        }
        return param0.intersection(param1);
    }

    private static void applyDeferredScissor(Rectangle rectangle) {
        ImmediateRenderer.setGuiScissor(rectangle == null
            ? null
            : new ScreenRect(rectangle.x, rectangle.y, rectangle.width, rectangle.height));
    }

    @Override
    public boolean test(Object param1) {
        return false;
    }

    static {
        ScissorUtil.method2622();
    }
}



