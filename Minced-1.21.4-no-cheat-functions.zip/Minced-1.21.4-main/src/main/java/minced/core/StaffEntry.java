/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 */
package minced.core;

import java.util.function.Function;

public class StaffEntry
{
    String field7992;

    public String method1996() {
        return this.field7992;
    }

    public StaffEntry(String param1) {
        this.field7992 = param1;
    }
}

