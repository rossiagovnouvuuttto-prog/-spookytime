package minced.core;

public enum BlockBreakPhase {
    START,
    STOP
}
