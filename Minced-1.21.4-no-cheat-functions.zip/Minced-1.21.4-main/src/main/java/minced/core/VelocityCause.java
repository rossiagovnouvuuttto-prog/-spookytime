package minced.core;

/** Source of an externally applied player velocity. */
public enum VelocityCause {
    ARROW,
    BLOCK,
    ENDER_PEARL,
    FALL
}
