package minced.core;

public enum ServerItemCategory {
    ARTIFACT,
    CONSUMABLE,
    SPHERE,
    TALISMAN,
    UNKNOWN
}
