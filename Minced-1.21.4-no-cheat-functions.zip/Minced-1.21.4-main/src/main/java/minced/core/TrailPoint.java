/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 */
package minced.core;

import java.util.function.Predicate;

public final class TrailPoint
{
    public float нШ;
    public double O;
    public double field9291;
    public double field9292;
    public long field9293;

    public TrailPoint(double param1, double param3, double param5) {
        this.O = param1;
        this.field9291 = param3;
        this.field9292 = param5;
        this.field9293 = System.currentTimeMillis();
    }
}

