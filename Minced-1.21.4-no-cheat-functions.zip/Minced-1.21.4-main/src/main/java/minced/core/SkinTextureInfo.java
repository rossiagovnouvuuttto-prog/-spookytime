package minced.core;

import net.minecraft.util.Identifier;

public record SkinTextureInfo(String id, String displayName, Identifier texture) {
}


