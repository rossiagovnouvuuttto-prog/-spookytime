package minced.core;

/** Marker interface for listeners associated with the bot network context. */
public interface ConnectionUtil {
}
