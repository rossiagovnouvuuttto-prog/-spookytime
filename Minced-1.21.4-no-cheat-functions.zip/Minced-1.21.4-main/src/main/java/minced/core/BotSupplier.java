/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 */
package minced.core;

import java.util.function.Supplier;

public interface BotSupplier
extends Supplier {
    default public void method1860() {
    }
}

