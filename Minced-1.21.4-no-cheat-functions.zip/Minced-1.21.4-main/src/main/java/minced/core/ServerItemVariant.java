package minced.core;

/** Server-provided rarity/rank value retained without lossy enum conversion. */
public record ServerItemVariant(String id) {
    public static ServerItemVariant parse(String id) {
        return id == null || id.isBlank() ? null : new ServerItemVariant(id.trim());
    }
}
