/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 */
package minced.core;

import minced.enums.NONE;
import minced.enums.NONE1;

public class ReconnectState
{
    NONE1 field847 = NONE1.NONE;
    String O = "";
    int field848 = -1;
    NONE field849 = NONE.NONE;
    int field850 = -1;
    boolean field851;
    boolean field852;
    boolean field853;
    boolean field854;
    boolean field855;

    public ReconnectState() {
    }

    final void method267() {
        this.field851 = false;
        this.field847 = NONE1.NONE;
        this.O = "";
        this.field848 = -1;
        this.field852 = false;
        this.field849 = NONE.NONE;
        this.field850 = -1;
        this.field853 = false;
        this.field854 = false;
        this.field855 = false;
    }
}

