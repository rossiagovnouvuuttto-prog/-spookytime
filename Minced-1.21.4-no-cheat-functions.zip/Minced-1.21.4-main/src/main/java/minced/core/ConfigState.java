/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 */
package minced.core;


public class ConfigState
{
    String field68;

    public void method68(String param1) {
        this.field68 = param1;
    }

    public String method69() {
        return this.field68;
    }
}

