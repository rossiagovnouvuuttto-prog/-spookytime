/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.RenderLayer$MultiPhaseParameters
 */
package minced.core;

public interface RenderLayerAccess
 {
}

