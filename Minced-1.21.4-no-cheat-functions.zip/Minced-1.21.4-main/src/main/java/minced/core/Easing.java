/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 */
package minced.core;

public interface Easing {
    public double method3420(double var1);
}

