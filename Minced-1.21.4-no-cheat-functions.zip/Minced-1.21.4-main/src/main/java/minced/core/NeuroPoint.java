/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 */
package minced.core;

import java.util.function.Predicate;

class NeuroPoint
{
    float field9281;
    float field9282;
    float field9283;

    public NeuroPoint(float param1, float param2, float param3) {
        this.field9281 = param1;
        this.field9282 = param2;
        this.field9283 = param3;
    }
}

