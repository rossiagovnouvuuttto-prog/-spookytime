package minced.core;

import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

public final class CachedSkinTexture {
    public final Identifier identifier;
    public final NativeImageBackedTexture texture;
    public final long lastModified;

    public CachedSkinTexture(Identifier identifier, NativeImageBackedTexture texture, long lastModified) {
        this.identifier = identifier;
        this.texture = texture;
        this.lastModified = lastModified;
    }
}


