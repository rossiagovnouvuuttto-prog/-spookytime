/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 * 
 * Could not load the following classes:
 *  net.minecraft.util.math.BlockPos
 *  sg.ec.Пв$2
 */
package minced.core;

import java.util.function.Predicate;
import minced.core.ClientState;
import net.minecraft.util.math.BlockPos;
import minced.deobfuscated.ObjectItemType;

public class ObjectItemPos
{
    public net.minecraft.util.math.BlockPos cfr_renamed_136;
    public minced.core.ClientState I;
    public ObjectItemType._2 н;
    public ObjectItemPos(BlockPos param1, ObjectItemType._2 param2) {
        this.I = new ClientState();
        this.cfr_renamed_136 = param1;
        this.н = param2;
        this.I.method3114();
    }
}




