package minced.core;

import org.joml.Matrix3x2fc;
import org.joml.Matrix4f;

/** Converts Minecraft's 1.21.11 GUI matrix into the 4x4 form used by legacy vertices. */
public final class GuiMatrixUtil {
    private GuiMatrixUtil() {
    }

    public static Matrix4f toMatrix4f(Matrix3x2fc matrix) {
        return new Matrix4f()
            .m00(matrix.m00()).m01(matrix.m01())
            .m10(matrix.m10()).m11(matrix.m11())
            .m30(matrix.m20()).m31(matrix.m21());
    }
}
