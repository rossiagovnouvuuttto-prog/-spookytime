package minced.core;

public interface Event {
}
