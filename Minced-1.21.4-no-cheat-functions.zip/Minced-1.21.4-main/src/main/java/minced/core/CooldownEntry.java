package minced.core;

import net.minecraft.item.Item;

/** A single item cooldown row rendered by the delays HUD. */
public record CooldownEntry(Item item, String name, String timeText, int ticksRemaining) {
}
