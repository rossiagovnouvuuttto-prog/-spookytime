package minced.core;

public final class TagEntry {
    public String н7;
    public float Шк;
    public int Ш必;

    public TagEntry(String param1, float param2, int param3) {
        this.н7 = param1;
        this.Шк = param2;
        this.Ш必 = param3;
    }
}
