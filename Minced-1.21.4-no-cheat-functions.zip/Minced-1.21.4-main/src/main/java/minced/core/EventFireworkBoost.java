/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 * 
 * Could not load the following classes:
 *  net.minecraft.util.math.Vec3d
 */
package minced.core;

import net.minecraft.util.math.Vec3d;

public class EventFireworkBoost {
    public Vec3d I;
    public Vec3d ь;
    public Vec3d cfr_renamed_136;

    public Vec3d method3587() {
        return this.I;
    }

    public void method3588(Vec3d param1) {
        this.I = param1;
    }

    public Vec3d method3589() {
        return this.ь;
    }

    public void method3590(Vec3d param1) {
        this.ь = param1;
    }

    public void method3591(Vec3d param1) {
        this.cfr_renamed_136 = param1;
    }

    public Vec3d method3592() {
        return this.cfr_renamed_136;
    }

    public EventFireworkBoost(Vec3d param1, Vec3d param2, Vec3d param3) {
        this.I = param1;
        this.cfr_renamed_136 = param2;
        this.ь = param3;
    }
}



