package minced.core;

import net.minecraft.util.math.Box;

/** A world-space box queued for fill and/or outline rendering. */
public record BoxRenderEntry(Box box, int color, boolean fill, boolean outline) {
}
