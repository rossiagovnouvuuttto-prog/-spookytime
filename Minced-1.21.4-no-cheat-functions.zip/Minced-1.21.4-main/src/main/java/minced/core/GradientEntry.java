/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.widget.ButtonWidget$PressAction
 */
package minced.core;

class GradientEntry
 {
    float field11713;
    float field11714;
    float field11715;
    float field11716;
    float field11717;
    float field11718;
    float field11719;
    float field11720;
    float field11721;
    float field11722;
    float field11723;
    float field11724;
    int field11725;
    int field11726;
    int field11727;
    int field11728;
    float field11729;
    float field11730;
    float field11731;
    float field11732;
    float field11733;
    float field11734;
    float field11735;
    float field11736;

    GradientEntry(float param1, float param2, float param3, float param4, float param5, float param6, float param7, float param8, float param9, float param10, float param11, float param12, int param13, int param14, int param15, int param16, float param17, float param18, float param19, float param20, float param21, float param22, float param23, float param24) {
        this.field11713 = param1;
        this.field11714 = param2;
        this.field11715 = param3;
        this.field11716 = param4;
        this.field11717 = param5;
        this.field11718 = param6;
        this.field11719 = param7;
        this.field11720 = param8;
        this.field11721 = param9;
        this.field11722 = param10;
        this.field11723 = param11;
        this.field11724 = param12;
        this.field11725 = param13;
        this.field11726 = param14;
        this.field11727 = param15;
        this.field11728 = param16;
        this.field11729 = param17;
        this.field11730 = param18;
        this.field11731 = param19;
        this.field11732 = param20;
        this.field11733 = param21;
        this.field11734 = param22;
        this.field11735 = param23;
        this.field11736 = param24;
    }
}

