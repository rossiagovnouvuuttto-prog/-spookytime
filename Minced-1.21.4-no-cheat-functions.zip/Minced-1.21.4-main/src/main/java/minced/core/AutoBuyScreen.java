package minced.core;

import minced.module.misc.ModuleClass114;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/** Minimal auto-buy configuration screen; settings remain owned by the module. */
public final class AutoBuyScreen extends Screen {
    private final AutoBuyState state;
    private final ModuleClass114 module;

    public AutoBuyScreen(AutoBuyState state, ModuleClass114 module) {
        super(Text.literal("Auto Buy"));
        this.state = state;
        this.module = module;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
        super.render(context, mouseX, mouseY, deltaTicks);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, 24, 0xFFFFFF);
    }
}
