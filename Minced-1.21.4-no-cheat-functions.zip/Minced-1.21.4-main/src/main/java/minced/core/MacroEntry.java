package minced.core;

/** A named keyboard macro and the chat command/message it sends. */
public record MacroEntry(String name, int keyCode, String command) {
}
