package minced.core;

import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.textures.GpuTexture;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Supplier;
import minced.compat.GlUniform;
import minced.render.ImmediateRenderer;
import minced.render.LegacyShaderProgram;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;

/** 1.21.11 implementation of Minced's legacy post-process program facade. */
public class ShaderProgramLoader implements Consumer<Object> {
    private final LegacyShaderProgram program;
    private final Map<String, Supplier<?>> samplers = new LinkedHashMap<>();

    public ShaderProgramLoader(PostEffectPipeline pipeline, String name) {
        this(pipeline, name, "minecraft");
    }

    public ShaderProgramLoader(PostEffectPipeline pipeline, String name, String namespace) {
        this.program = new LegacyShaderProgram(Identifier.of(namespace, "program/" + name), VertexFormats.POSITION);
    }

    @Override
    public void accept(Object ignored) {
        method2097();
    }

    public GlUniform method2090(String name) {
        return method2093(name, null);
    }

    public GlUniform method2093(String name, GlUniform fallback) {
        LegacyShaderProgram.UniformValue value = program.uniformOrNull(name);
        return value == null ? fallback : new GlUniform(value);
    }

    public void method2092(String name, Supplier<?> supplier) {
        samplers.put(name, supplier);
    }

    public void method2097() {
        for (Map.Entry<String, Supplier<?>> entry : samplers.entrySet()) {
            Object texture = entry.getValue().get();
            if (texture instanceof GpuTextureView view) {
                ImmediateRenderer.setTexture(entry.getKey(), view, FilterMode.LINEAR);
            } else if (texture instanceof GpuTexture gpuTexture) {
                ImmediateRenderer.setTexture(entry.getKey(), RenderSystem.getDevice().createTextureView(gpuTexture), FilterMode.LINEAR);
            }
        }
        program.bind();
    }

    public void method2088() {
        ImmediateRenderer.clearShader();
        ImmediateRenderer.clearTexture();
    }

    public static void method2095() {
    }
}
