package minced.core;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.BlockPos;

/**
 * Событие касания паутины (диспатчится из CobwebBlockMixin, обрабатывается NoWeb).
 * Бывшая авто-заглушка: generic-методы возвращали null, и миксин падал на распаковке
 * Boolean при касании паутины любой сущностью.
 */
public class CobwebCollisionEvent {
    private final LivingEntity entity;
    private final BlockPos pos;
    private boolean cancelled;

    public CobwebCollisionEvent(LivingEntity entity, BlockPos pos) {
        this.entity = entity;
        this.pos = pos;
    }

    public LivingEntity getEntity() {
        return this.entity;
    }

    public BlockPos getPos() {
        return this.pos;
    }

    public void setCancelled(boolean value) {
        this.cancelled = value;
    }

    public boolean isCancelled() {
        return this.cancelled;
    }
}
