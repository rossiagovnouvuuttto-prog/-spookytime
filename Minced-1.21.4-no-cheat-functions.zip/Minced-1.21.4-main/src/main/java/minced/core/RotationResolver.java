package minced.core;

public interface RotationResolver {
    default void releaseResolver() {}
    default void resolve() {}
}
