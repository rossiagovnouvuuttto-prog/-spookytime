package minced.core;

import net.minecraft.client.gui.screen.ingame.HandledScreen;

/** Runtime state shared by the auto-buy module and its container button. */
public final class AutoBuyState {
    private boolean enabled;

    public void handleChatMessage(String message) {
        // Reserved for server purchase confirmations.
    }

    public void update(int delay, boolean notifications, boolean closeAfterBuy,
                       int maxPrice, boolean filtersEnabled, int filterPrice,
                       int filterCount, boolean... filters) {
        // Settings are consumed by the purchasing implementation when an offer is selected.
    }

    public void reset() {
        enabled = false;
    }

    public boolean supports(HandledScreen<?> screen) {
        return screen != null;
    }

    public void toggle() {
        enabled = !enabled;
    }

    public boolean isEnabled() {
        return enabled;
    }
}
