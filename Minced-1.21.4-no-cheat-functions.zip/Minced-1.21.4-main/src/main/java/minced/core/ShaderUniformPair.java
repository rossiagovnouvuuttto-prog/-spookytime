/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 */
package minced.core;

public class ShaderUniformPair {
    Object I;
    Object field8034;

    public ShaderUniformPair(Object param1, Object param2) {
        this.I = param1;
        this.field8034 = param2;
    }
}



