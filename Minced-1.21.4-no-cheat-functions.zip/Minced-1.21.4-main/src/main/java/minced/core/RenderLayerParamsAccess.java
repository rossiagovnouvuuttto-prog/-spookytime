/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 * 
 * Could not load the following classes:
 *  net.minecraft.client.render.RenderLayer$OutlineMode
 *  net.minecraft.client.render.RenderPhase$Target
 *  net.minecraft.client.render.RenderPhase$TextureBase
 */
package minced.core;

public interface RenderLayerParamsAccess
{
}

