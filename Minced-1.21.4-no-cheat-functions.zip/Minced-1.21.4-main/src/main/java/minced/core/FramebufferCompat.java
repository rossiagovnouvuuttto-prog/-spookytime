package minced.core;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.Map;
import java.util.WeakHashMap;
import minced.render.ImmediateRenderer;
import net.minecraft.client.gl.Framebuffer;

/** Compatibility operations for framebuffer methods removed in 1.21.11. */
public final class FramebufferCompat {
    private static final Map<Framebuffer, Integer> CLEAR_COLORS = new WeakHashMap<>();

    private FramebufferCompat() {
    }

    public static void setClearColor(Framebuffer framebuffer, float red, float green, float blue, float alpha) {
        int color = (Math.round(alpha * 255.0f) << 24)
            | (Math.round(red * 255.0f) << 16)
            | (Math.round(green * 255.0f) << 8)
            | Math.round(blue * 255.0f);
        CLEAR_COLORS.put(framebuffer, color);
    }

    public static void clear(Framebuffer framebuffer) {
        int color = CLEAR_COLORS.getOrDefault(framebuffer, 0);
        var encoder = RenderSystem.getDevice().createCommandEncoder();
        if (framebuffer.useDepthAttachment && framebuffer.getDepthAttachment() != null) {
            encoder.clearColorAndDepthTextures(framebuffer.getColorAttachment(), color, framebuffer.getDepthAttachment(), 1.0);
        } else {
            encoder.clearColorTexture(framebuffer.getColorAttachment(), color);
        }
    }

    public static void beginWrite(Framebuffer framebuffer, boolean clear) {
        ImmediateRenderer.setTarget(framebuffer);
        if (clear) clear(framebuffer);
    }

    public static void endWrite(Framebuffer framebuffer) {
        ImmediateRenderer.clearTarget();
    }

    public static void beginRead(Framebuffer framebuffer) {
        ImmediateRenderer.setTexture(framebuffer.getColorAttachmentView());
    }

    public static void endRead(Framebuffer framebuffer) {
        ImmediateRenderer.clearTexture();
    }
}
