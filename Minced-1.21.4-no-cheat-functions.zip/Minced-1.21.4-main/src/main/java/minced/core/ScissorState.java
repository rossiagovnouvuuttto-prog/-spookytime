/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 */
package minced.core;

import java.util.function.Predicate;

final class ScissorState
{
    boolean field9294;
    int[] field9295;

    ScissorState(boolean param1, int[] param2) {
        this.field9294 = param1;
        this.field9295 = param2;
    }
}

