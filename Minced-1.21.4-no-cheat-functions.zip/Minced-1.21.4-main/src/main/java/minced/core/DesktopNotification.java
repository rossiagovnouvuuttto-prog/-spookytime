package minced.core;

import java.awt.AWTException;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.SystemTray;
import java.awt.TrayIcon;
import java.awt.image.BufferedImage;

/** Displays a native desktop notification when the game is unfocused. */
public final class DesktopNotification {
    private DesktopNotification() {
    }

    public static void show(String title, String message) {
        if (!SystemTray.isSupported()) {
            return;
        }
        BufferedImage image = new BufferedImage(16, 16, BufferedImage.TYPE_INT_ARGB);
        Graphics2D graphics = image.createGraphics();
        graphics.setColor(new Color(36, 211, 158));
        graphics.fillOval(1, 1, 14, 14);
        graphics.dispose();

        SystemTray tray = SystemTray.getSystemTray();
        TrayIcon icon = new TrayIcon(image, "Minced");
        icon.setImageAutoSize(true);
        try {
            tray.add(icon);
            icon.displayMessage(title, message, TrayIcon.MessageType.INFO);
            Thread.ofVirtual().start(() -> {
                try {
                    Thread.sleep(5000L);
                } catch (InterruptedException ignored) {
                    Thread.currentThread().interrupt();
                } finally {
                    tray.remove(icon);
                }
            });
        } catch (AWTException ignored) {
            // Native notifications may be unavailable in fullscreen/headless sessions.
        }
    }
}
