package minced.core;

import net.minecraft.item.ItemStack;

/** Parsed metadata for custom items supplied by supported server networks. */
public record ServerItemMetadata(
        ServerItemCategory category,
        String customName,
        ServerItemVariant variant,
        ServerNetwork network) {

    public ServerItemMetadata(ServerItemCategory category, String customName, ServerNetwork network) {
        this(category, customName, null, network);
    }

    public boolean isConsumable() {
        return category == ServerItemCategory.CONSUMABLE;
    }

    public boolean isTalisman() {
        return category == ServerItemCategory.TALISMAN;
    }

    public boolean isSphere() {
        return category == ServerItemCategory.SPHERE;
    }

    public boolean isArtifact() {
        return category == ServerItemCategory.ARTIFACT;
    }

    public String displayName(ItemStack stack) {
        if (customName != null && !customName.isBlank()) {
            Object translated = ServerItemTags.field10030.get(customName);
            return translated instanceof String ? (String) translated : customName;
        }
        return stack.getName().getString();
    }

    public int displayColor(ItemStack stack) {
        if (variant != null) {
            Object variantColor = ServerItemTags.field9995.get(variant.id());
            if (variantColor instanceof Integer) {
                return (Integer) variantColor;
            }
        }
        return switch (category) {
            case CONSUMABLE -> ServerItemTags.field10032;
            case TALISMAN -> ServerItemTags.field10034;
            case SPHERE -> ServerItemTags.cfr_underscore;
            case ARTIFACT -> ServerItemTags.cfr_renamed_0;
            case UNKNOWN -> ServerItemTags.field10038;
        };
    }
}
