/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 * 
 * Could not load the following classes:
 *  net.minecraft.client.gui.DrawContext
 */
package minced.core;

import net.minecraft.client.gui.DrawContext;

public interface ColorPickerRenderer {
    default public void method3154(float param1, float param2, int param3) {
    }

    default public void method3155(int param1, int param2, int param3) {
    }

    default public boolean method3156(double param1, double param3, double param5, double param7) {
        return false;
    }

    default public void method3157(char param1, int param2) {
    }

    default public void method3158(float param1, float param2, int param3) {
    }

    default public boolean method3159(double param1, double param3, int param5, double param6, double param8) {
        return false;
    }

    default public void method3160(float param1, float param2, int param3) {
    }

    default public void method3161(DrawContext param1, float param2, float param3, float param4) {
    }

    default public void method3162(int param1, int param2, int param3) {
    }

    default public boolean method3163(double param1, double param3, int param5, double param6, double param8) {
        return false;
    }

    default public boolean method3164(double param1, double param3, double param5, double param7) {
        return false;
    }

    default public boolean method3165(float param1, float param2, int param3) {
        return false;
    }

    default public void method3166(char param1, int param2) {
    }

    default public void method3167(DrawContext param1, float param2, float param3, float param4) {
    }
}

