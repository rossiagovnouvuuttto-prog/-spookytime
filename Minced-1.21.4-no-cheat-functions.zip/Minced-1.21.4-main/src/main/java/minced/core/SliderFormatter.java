/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 */
package minced.core;

interface SliderFormatter
 {
    public void method1966(String var1);
}

