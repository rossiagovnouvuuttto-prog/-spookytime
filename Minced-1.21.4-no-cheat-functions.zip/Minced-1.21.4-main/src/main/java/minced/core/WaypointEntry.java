package minced.core;

/** A named world position persisted by the waypoint manager. */
public record WaypointEntry(String name, double x, double y, double z) {
}
