package minced.core;

import minced.core.BotContext;
import minced.core.RecordClass229;
import net.minecraft.client.MinecraftClient;

public final class MinecraftClientState {
    private MinecraftClientState() {
    }

    public static RecordClass229 snapshot(MinecraftClient client) {
        if (client == null) {
            return null;
        }
        return new RecordClass229(client.world, client.player, client.interactionManager, client.getCameraEntity(), client.crosshairTarget, client.targetedEntity);
    }

    public static void restore(MinecraftClient client, RecordClass229 snapshot) {
        if (client == null || snapshot == null) {
            return;
        }
        client.world = snapshot.world();
        client.player = snapshot.player();
        client.interactionManager = snapshot.interactionManager();
        client.setCameraEntity(snapshot.cameraEntity());
        client.crosshairTarget = snapshot.crosshairTarget();
        client.targetedEntity = snapshot.targetedEntity();
    }

    public static void applyBot(MinecraftClient client, BotContext bot) {
        if (client == null || bot == null) {
            return;
        }
        client.world = bot.method_2890();
        client.player = bot.getPlayer();
        client.interactionManager = bot.getInteractionManager();
        client.setCameraEntity(bot.method3584());
    }

}


