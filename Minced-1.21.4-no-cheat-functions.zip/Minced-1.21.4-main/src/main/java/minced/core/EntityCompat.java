package minced.core;

import java.util.List;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;

/** Small adapters for entity APIs that changed after 1.21.4. */
public final class EntityCompat {
    private EntityCompat() {
    }

    public static Iterable<ItemStack> getArmorItems(LivingEntity entity) {
        return List.of(
            entity.getEquippedStack(EquipmentSlot.FEET),
            entity.getEquippedStack(EquipmentSlot.LEGS),
            entity.getEquippedStack(EquipmentSlot.CHEST),
            entity.getEquippedStack(EquipmentSlot.HEAD)
        );
    }

    /** Legacy armor index order: boots, leggings, chestplate, helmet. */
    public static ItemStack getArmorStack(LivingEntity entity, int index) {
        return entity.getEquippedStack(switch (index) {
            case 0 -> EquipmentSlot.FEET;
            case 1 -> EquipmentSlot.LEGS;
            case 2 -> EquipmentSlot.CHEST;
            case 3 -> EquipmentSlot.HEAD;
            default -> throw new IndexOutOfBoundsException("Armor slot " + index);
        });
    }
}
