/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 */
package minced.core;

import minced.core.BotSession;

public interface BotAction
{
    public void method192(BotSession var1);

    public String method193();
}

