/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 */
package minced.core;

import minced.core.EventRender2D;

public interface HudComponent {
    public void method2818(EventRender2D var1);
}

