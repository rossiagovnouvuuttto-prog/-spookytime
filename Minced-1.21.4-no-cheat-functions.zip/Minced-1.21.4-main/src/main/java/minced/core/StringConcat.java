package minced.core;

/** Plain Java replacement for the string-concatenation bridge left by the old VM obfuscator. */
public final class StringConcat {
    private StringConcat() {
    }

    public static String concat(Object... values) {
        if (values == null || values.length == 0) {
            return "";
        }
        StringBuilder result = new StringBuilder();
        for (Object value : values) {
            if (value != null && !(value instanceof Object[])) {
                result.append(value);
            }
        }
        return result.toString();
    }
}
