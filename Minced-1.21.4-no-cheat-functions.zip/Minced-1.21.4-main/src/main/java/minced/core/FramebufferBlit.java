/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 * 
 * Could not load the following classes:
 *  com.mojang.blaze3d.platform.GlStateManager
 *  com.mojang.blaze3d.systems.RenderSystem
 *  net.minecraft.client.gl.Framebuffer
 *  net.minecraft.client.gl.ShaderProgram
 *  net.minecraft.client.gl.ShaderProgramKey
 *  net.minecraft.client.gl.ShaderProgramKeys
 *  net.minecraft.client.render.BufferBuilder
 *  net.minecraft.client.render.BufferRenderer
 *  net.minecraft.client.render.BuiltBuffer
 *  net.minecraft.client.render.VertexFormat$DrawMode
 *  net.minecraft.client.render.VertexFormats
 */
package minced.core;

import minced.compat.GlStateManager;
import minced.compat.RenderSystem;
import java.util.Objects;
import net.minecraft.client.gl.Framebuffer;
import minced.compat.ShaderProgram;
import minced.compat.ShaderProgramKey;
import minced.compat.ShaderProgramKeys;
import net.minecraft.client.render.BufferBuilder;
import minced.compat.BufferRenderer;
import net.minecraft.client.render.BuiltBuffer;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.render.VertexFormats;

public class FramebufferBlit
{
    public static boolean field763;
    static String field764;
    static String field765;

    public static void method204() {
        field763 = true;
    }

    public static void method205(Framebuffer param0, int param1, int param2) {
        RenderSystem.assertOnRenderThread();
        ClientUtil.I.getFramebuffer().drawBlit(param0.getColorAttachmentView());
    }

    static {
        field763 = true;
        field764 = "Blit shader not loaded";
        field765 = "InSampler";
        FramebufferBlit.method204();
    }
}



