package minced.core;

import net.minecraft.client.gl.SimpleFramebuffer;

/** SimpleFramebuffer retaining the small stateful API used by Minced. */
public class LegacyFramebuffer extends SimpleFramebuffer {
    public LegacyFramebuffer(String name, int width, int height, boolean depth) {
        super(name, width, height, depth);
    }

    public LegacyFramebuffer(int width, int height, boolean depth) {
        this("Minced framebuffer", width, height, depth);
    }

    public void setClearColor(float red, float green, float blue, float alpha) {
        FramebufferCompat.setClearColor(this, red, green, blue, alpha);
    }

    public void clear() { FramebufferCompat.clear(this); }
    public void beginWrite(boolean clear) { FramebufferCompat.beginWrite(this, clear); }
    public void endWrite() { FramebufferCompat.endWrite(this); }
    public void beginRead() { FramebufferCompat.beginRead(this); }
    public void endRead() { FramebufferCompat.endRead(this); }
}
