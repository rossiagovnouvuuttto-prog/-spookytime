package minced.core;

/** A rectangle with an independently colored value at each corner. */
public record GradientRect(float x, float y, float width, float height,
                           int topLeft, int bottomLeft, int bottomRight, int topRight) {
}
