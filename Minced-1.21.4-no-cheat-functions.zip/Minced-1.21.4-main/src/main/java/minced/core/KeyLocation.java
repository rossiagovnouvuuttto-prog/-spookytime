package minced.core;

import minced.enums.NOTLOOTED;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

/** A possible key location discovered in a minecart or dungeon spawner. */
public record KeyLocation(
        Vec3d position,
        int referenceId,
        KeyLocationType type,
        NOTLOOTED lootState,
        int nearbyChestCount) {

    public KeyLocation(BlockPos position, int referenceId, KeyLocationType type,
                       NOTLOOTED lootState, int nearbyChestCount) {
        this(Vec3d.ofCenter(position), referenceId, type, lootState, nearbyChestCount);
    }
}
