package minced.core;

import minced.core.AccountEntry;
import minced.core.ThemeColors;
import minced.core.ColorUtil;
import minced.core.Fonts;
import minced.core.MathUtil;
import minced.core.RenderUtil;
import minced.enums.MAIN;
import minced.manager.Account;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.util.DefaultSkinHelper;
import net.minecraft.util.Identifier;

/**
 * Карточка аккаунта в альт-менеджере (используется только из WidgetAccountList).
 * Бывшая авто-заглушка с null-методами — клик по списку аккаунтов ронял клиент.
 * Реализация восстановлена по контракту вызовов: сеттеры геометрии, колбэки
 * выбора/избранного/удаления и отрисовка карточки с именем, звёздочкой и крестиком.
 */
public class AccountCard {
    private static final float BUTTON_ZONE = 14.0f;
    private static final float AVATAR_SIZE = 16.0f;

    private float x;
    private float y;
    private float width;
    private float height;
    private AccountEntry account;
    private Account manager;
    private boolean selected;
    private Runnable selectCallback;
    private Runnable favoriteCallback;
    private Runnable deleteCallback;

    public AccountCard(float x, float y, float width, float height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }

    public AccountEntry getAccount() {
        return this.account;
    }

    public void setAccount(AccountEntry account) {
        this.account = account;
    }

    public void setManager(Account manager) {
        this.manager = manager;
    }

    public void setSelectCallback(Runnable callback) {
        this.selectCallback = callback;
    }

    public void setFavoriteCallback(Runnable callback) {
        this.favoriteCallback = callback;
    }

    public void setDeleteCallback(Runnable callback) {
        this.deleteCallback = callback;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    public void setX(float x) {
        this.x = x;
    }

    public void setY(float y) {
        this.y = y;
    }

    public void setWidth(float width) {
        this.width = width;
    }

    public void setHeight(float height) {
        this.height = height;
    }

    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        int accent = ThemeColors.method3199(MAIN.MODULE_VISUAL);
        boolean hovered = MathUtil.cfr_underscore((float)mouseX, (float)mouseY, this.x, this.y, this.width, this.height);
        int background = this.selected
                ? ColorUtil.method1855(accent, 90)
                : ColorUtil.method1852(255, 255, 255, hovered ? 30 : 16);
        RenderUtil.method397(this.x, this.y, this.width, this.height, 4.0f, background);
        var font = Fonts.field12486[12];
        var controlFont = Fonts.field12494[11];
        String name = this.account != null ? this.account.getName() : "";
        float textY = this.y + (this.height - font.method2718()) / 2.0f;
        float avatarX = this.x + 5.0f;
        float avatarY = this.y + (this.height - AVATAR_SIZE) / 2.0f;
        RenderUtil.method389(this.getSkinTexture(name), null, avatarX, avatarY,
                AVATAR_SIZE, AVATAR_SIZE, 3.0f, 1.0f);
        font.method2711(context, name, avatarX + AVATAR_SIZE + 5.0f, textY,
                this.selected ? -1 : ColorUtil.method1852(255, 255, 255, 220));
        String star = this.account != null && this.account.isFavorite() ? "★" : "☆";
        String favoriteSymbol = this.account != null && this.account.isFavorite() ? "*" : "+";
        float controlY = this.y + (this.height - controlFont.method2718()) / 2.0f;
        controlFont.method2711(context, favoriteSymbol, this.x + this.width - BUTTON_ZONE * 2.0f + 4.0f, controlY,
                this.account != null && this.account.isFavorite() ? accent : ColorUtil.method1852(255, 255, 255, 140));
        controlFont.method2711(context, "x", this.x + this.width - BUTTON_ZONE + 4.0f, controlY,
                ColorUtil.method1852(255, 100, 100, 210));
        if (this.selected) {
            RenderUtil.method397(this.x, this.y + 5.0f, 2.0f, this.height - 10.0f, 1.0f, accent);
        }
    }

    private Identifier getSkinTexture(String name) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.getNetworkHandler() != null && name != null && !name.isBlank()) {
            PlayerListEntry entry = client.getNetworkHandler().getPlayerListEntry(name);
            if (entry != null) {
                return entry.getSkinTextures().body().texturePath();
            }
        }
        return DefaultSkinHelper.getTexture();
    }

    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (button != 0 || !MathUtil.cfr_underscore((float)mouseX, (float)mouseY, this.x, this.y, this.width, this.height)) {
            return false;
        }
        if (mouseX >= (double)(this.x + this.width - BUTTON_ZONE)) {
            if (this.deleteCallback != null) {
                this.deleteCallback.run();
            }
            return true;
        }
        if (mouseX >= (double)(this.x + this.width - BUTTON_ZONE * 2.0f)) {
            if (this.account != null) {
                this.account.setFavorite(!this.account.isFavorite());
            }
            if (this.favoriteCallback != null) {
                this.favoriteCallback.run();
            }
            return true;
        }
        if (this.selectCallback != null) {
            this.selectCallback.run();
        }
        return true;
    }
}


