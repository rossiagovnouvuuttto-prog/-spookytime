/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 */
package minced.core;

import java.util.function.Function;
import minced.core.Easings;
import minced.core.AnimatedFloat;

public final class ConfigEntry {
    static float field7979 = 8.0f;
    AnimatedFloat field7980 = new AnimatedFloat(0.0f, field7979, Easings.field11957);
    static float field7981 = 14.0f;
    AnimatedFloat field7982 = new AnimatedFloat(0.0f, field7981, Easings.field11969);
    static float field7983 = 14.0f;
    AnimatedFloat field7984 = new AnimatedFloat(0.0f, field7983, Easings.field11969);
    static float field7985 = 14.0f;
    AnimatedFloat field7986 = new AnimatedFloat(0.0f, field7985, Easings.field11969);
    static float field7987 = 14.0f;
    AnimatedFloat field7988 = new AnimatedFloat(0.0f, field7987, Easings.field11969);

    public ConfigEntry() {
    }
}

