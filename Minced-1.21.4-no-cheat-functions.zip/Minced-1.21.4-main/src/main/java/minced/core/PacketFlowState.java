/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 */
package minced.core;

public class PacketFlowState {
    public static boolean field8033;

    public static void method2051() {
        field8033 = false;
    }

    static {
        field8033 = false;
        PacketFlowState.method2051();
    }
}

