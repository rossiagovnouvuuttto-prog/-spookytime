package minced.core;

import net.minecraft.item.ItemStack;
import net.minecraft.registry.tag.ItemTags;

/** Item category checks for the data-driven 1.21.11 item system. */
public final class ItemCompat {
    private ItemCompat() {
    }

    public static boolean isSword(ItemStack stack) {
        return stack != null && !stack.isEmpty() && stack.isIn(ItemTags.SWORDS);
    }

    public static boolean isArmor(ItemStack stack) {
        return stack != null && !stack.isEmpty() && (
            stack.isIn(ItemTags.HEAD_ARMOR)
                || stack.isIn(ItemTags.CHEST_ARMOR)
                || stack.isIn(ItemTags.LEG_ARMOR)
                || stack.isIn(ItemTags.FOOT_ARMOR)
        );
    }
}
