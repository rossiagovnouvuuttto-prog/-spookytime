/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 */
package minced.core;

import minced.core.CancellableEvent;
import minced.core.EventBase;

public class EventSprint
extends EventBase
implements CancellableEvent {
}

