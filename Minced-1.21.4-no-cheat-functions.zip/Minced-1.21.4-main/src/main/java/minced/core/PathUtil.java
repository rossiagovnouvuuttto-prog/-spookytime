/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 * 
 * Could not load the following classes:
 *  sLM.4ZXYEo
 */
package minced.core;

public class PathUtil {
    static String cfr_renamed_118;

    static String field7557;
    public static String field7558;

    public static void method1844() {
        field7558 = minced.core.StringConcat.concat((String)System.getenv(field7557));
    }

    static {
        field7558 = "C:\\Minced\\";
        field7557 = "SystemDrive";
        cfr_renamed_118 = "\u0001\\Minced\\";
        PathUtil.method1844();
    }
}

