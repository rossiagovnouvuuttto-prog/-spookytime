package minced.core;

import minced.render.ImmediateRenderer;

/**
 * Lifecycle bridge for the legacy hand post-processing module.
 *
 * <p>The original implementation depended on numeric OpenGL framebuffer and
 * texture ids. Minecraft 1.21.11 renders through the explicit GPU API, so those
 * calls can no longer be emulated safely. The hooks remain intentionally cheap
 * and restore the default render target, allowing vanilla hands to render while
 * a proper frame-graph implementation is selected by the new renderer.</p>
 */
public final class HandsShader {
    private static final HandsShader INSTANCE = new HandsShader();

    private HandsShader() {
    }

    public static HandsShader method1933() {
        return INSTANCE;
    }

    public void method1920() {
        ImmediateRenderer.clearTarget();
    }

    public void method1922() {
        ImmediateRenderer.clearTarget();
    }

    public void method1930() {
        ImmediateRenderer.clearTarget();
        ImmediateRenderer.clearTexture();
    }

    public void method1916() {
        method1930();
    }
}
