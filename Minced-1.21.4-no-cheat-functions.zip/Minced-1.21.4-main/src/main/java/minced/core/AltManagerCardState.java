package minced.core;

final class AltManagerCardState {
    boolean ШЕ;
    int Шш;
    int ША;
    AltManagerCardState() {}
}
