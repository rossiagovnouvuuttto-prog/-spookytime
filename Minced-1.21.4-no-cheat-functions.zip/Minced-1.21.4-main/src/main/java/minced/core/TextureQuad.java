package minced.core;

/** A tinted textured rectangle queued for batched GUI rendering. */
public record TextureQuad(float x, float y, float width, float height, int color) {
}
