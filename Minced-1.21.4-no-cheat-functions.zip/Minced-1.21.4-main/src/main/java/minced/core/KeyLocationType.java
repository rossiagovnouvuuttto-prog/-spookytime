package minced.core;

public enum KeyLocationType {
    MINECART,
    SPAWNER
}
