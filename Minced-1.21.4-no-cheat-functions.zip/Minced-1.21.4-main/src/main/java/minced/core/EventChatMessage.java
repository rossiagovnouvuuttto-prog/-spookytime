/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 */
package minced.core;


public class EventChatMessage
{
    String field74;

    public String method76() {
        return this.field74;
    }

    public EventChatMessage(String param1) {
        this.field74 = param1;
    }
}

