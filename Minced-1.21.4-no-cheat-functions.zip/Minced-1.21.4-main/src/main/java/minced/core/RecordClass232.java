package minced.core;

public final class RecordClass232 {
    public final boolean enabled;
    public final String action;

    public RecordClass232(boolean enabled, String action) {
        this.enabled = enabled;
        this.action = BotManager.method2127(action);
    }

    public boolean enabled() { return enabled; }
    public String action() { return action; }
}
