/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 */
package minced.core;


public class Glyph
{
    public float х;
    public float ъ;
    public float ы;
    public float Ю;
}

