package minced.core;

public enum ServerNetwork {
    FUNTIME,
    HOLYWORLD,
    SPOOKYTIME
}
