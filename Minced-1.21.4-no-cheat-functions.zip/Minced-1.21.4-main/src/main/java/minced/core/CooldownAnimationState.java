package minced.core;

/** Per-item animations used by the delays HUD. */
public final class CooldownAnimationState {
    public final Animation offset = new Animation(Easings.field11957, 0.0f, 200L);
    public final Animation visibility = new Animation(Easings.field11957, 0.0f, 200L);
}
