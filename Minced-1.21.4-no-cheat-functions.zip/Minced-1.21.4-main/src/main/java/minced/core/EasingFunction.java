/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 */
package minced.core;

public interface EasingFunction {
    public double O(double var1);
}

