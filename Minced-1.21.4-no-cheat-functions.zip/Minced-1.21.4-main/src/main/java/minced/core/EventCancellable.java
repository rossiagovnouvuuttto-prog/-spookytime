/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 */
package minced.core;

public abstract class EventCancellable {
    public boolean нЪ;

    protected EventCancellable() {
    }

    public boolean method2052() {
        return this.нЪ;
    }

    public void method2053() {
        this.нЪ = true;
    }
}

