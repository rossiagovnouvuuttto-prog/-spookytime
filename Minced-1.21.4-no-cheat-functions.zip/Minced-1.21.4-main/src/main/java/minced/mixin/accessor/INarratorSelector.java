/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 * 
 * Could not load the following classes:
 *  com.mojang.text2speech.Narrator
 *  org.spongepowered.asm.mixin.Mixin
 */
package minced.mixin.accessor;
import com.mojang.text2speech.Narrator;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(value={Narrator.class})
public interface INarratorSelector {
}



