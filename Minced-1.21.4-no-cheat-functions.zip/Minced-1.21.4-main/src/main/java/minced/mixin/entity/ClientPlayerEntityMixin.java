/*
 * Decompiled with CFR 0.153-SNAPSHOT (eccbb2d).
 * 
 * Could not load the following classes:
 *  net.minecraft.client.network.ClientPlayNetworkHandler
 *  net.minecraft.client.network.ClientPlayerEntity
 *  net.minecraft.client.option.KeyBinding
 *  net.minecraft.network.NetworkPhase
 *  net.minecraft.network.listener.PacketListener
 *  net.minecraft.util.math.BlockPos
 *  org.spongepowered.asm.mixin.Mixin
 *  org.spongepowered.asm.mixin.Unique
 *  org.spongepowered.asm.mixin.injection.At
 *  org.spongepowered.asm.mixin.injection.Constant
 *  org.spongepowered.asm.mixin.injection.Inject
 *  org.spongepowered.asm.mixin.injection.ModifyConstant
 *  org.spongepowered.asm.mixin.injection.Redirect
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfo
 *  org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable
 */
package minced.mixin.entity;
import minced.core.EventUpdate;
import minced.core.EventSprint;
import minced.core.EventNoSlow;
import minced.core.RotationManager;
import minced.core.EventNoPush;
import minced.core.EventInventoryClose;
import minced.core.EventMotion;
import minced.core.EventPostUpdate;
import minced.core.EventPreTick;
import minced.core.EventPostTick;
import minced.core.Event;
import minced.core.EventBus;
import minced.core.ConnectionUtil;
import minced.core.EventBlockRayTrace;
import minced.core.EventMouseOver;
import minced.core.RaytraceAccess;
import minced.enums.Block;
import net.minecraft.block.BlockState;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.NetworkPhase;
import net.minecraft.network.listener.PacketListener;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.predicate.entity.EntityPredicates;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Position;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.PlayerInput;
import net.minecraft.world.RaycastContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(value={ClientPlayerEntity.class})
public class ClientPlayerEntityMixin {
    @Unique
    private EventMotion eventMotion;

    @Redirect(method={"getCrosshairTarget(FLnet/minecraft/entity/Entity;)Lnet/minecraft/util/hit/HitResult;"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/network/ClientPlayerEntity;getCrosshairTarget(Lnet/minecraft/entity/Entity;DDF)Lnet/minecraft/util/hit/HitResult;"))
    private HitResult minced$findCrosshairTarget(Entity cameraEntity, double blockRange, double entityRange, float tickDelta) {
        Vec3d start = cameraEntity.getCameraPosVec(tickDelta);
        EventMouseOver mouseOver = new EventMouseOver(start, new Vec2f(cameraEntity.getYaw(tickDelta), cameraEntity.getPitch(tickDelta)));
        EventBus.method3015(mouseOver);
        start = mouseOver.method3561();
        Vec3d direction = minced$getRotationVector(mouseOver.method3563()).normalize();
        double range = Math.max(blockRange, entityRange);
        double squaredRange = MathHelper.square(range);
        Vec3d end = start.add(direction.multiply(range));
        BlockHitResult blockHit = cameraEntity.getEntityWorld().raycast(new RaycastContext(
                start, end, RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.NONE, cameraEntity));

        for (int pass = 0; pass < 32 && blockHit.getType() == HitResult.Type.BLOCK; pass++) {
            BlockState state = cameraEntity.getEntityWorld().getBlockState(blockHit.getBlockPos());
            EventBlockRayTrace blockEvent = new EventBlockRayTrace(state, blockHit.getBlockPos());
            EventBus.method3015(blockEvent);
            if (!blockEvent.method2297()) {
                break;
            }
            BlockPos ignoredPos = blockHit.getBlockPos();
            double offset = 0.01;
            Vec3d next = blockHit.getPos().add(direction.multiply(offset));
            while (offset < 1.0 && BlockPos.ofFloored((Position)next).equals(ignoredPos)) {
                offset *= 2.0;
                next = blockHit.getPos().add(direction.multiply(offset));
            }
            blockHit = cameraEntity.getEntityWorld().raycast(new RaycastContext(
                    next, end, RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.NONE, cameraEntity));
        }

        double blockDistance = blockHit.getPos().squaredDistanceTo(start);
        if (blockHit.getType() != HitResult.Type.MISS) {
            squaredRange = blockDistance;
            range = Math.sqrt(blockDistance);
        }
        Vec3d entityEnd = start.add(direction.multiply(range));
        EntityHitResult entityHit = ProjectileUtil.raycast(cameraEntity, start, entityEnd,
                cameraEntity.getBoundingBox().stretch(direction.multiply(range)).expand(1.0, 1.0, 1.0),
                entity -> EntityPredicates.CAN_HIT.test(entity) && ((RaytraceAccess)entity).canBeRaytracing(), squaredRange);
        return entityHit != null && entityHit.getPos().squaredDistanceTo(start) < blockDistance
                ? minced$ensureTargetInRange(entityHit, start, entityRange)
                : minced$ensureTargetInRange(blockHit, start, blockRange);
    }

    @Unique
    private static Vec3d minced$getRotationVector(Vec2f rotation) {
        float yawCos = MathHelper.cos(-rotation.x * 0.017453292f - (float)Math.PI);
        float yawSin = MathHelper.sin(-rotation.x * 0.017453292f - (float)Math.PI);
        float pitchCos = -MathHelper.cos(-rotation.y * 0.017453292f);
        float pitchSin = MathHelper.sin(-rotation.y * 0.017453292f);
        return new Vec3d(yawSin * pitchCos, pitchSin, yawCos * pitchCos);
    }

    @Unique
    private static HitResult minced$ensureTargetInRange(HitResult result, Vec3d start, double range) {
        Vec3d pos = result.getPos();
        if (pos.isInRange((Position)start, range)) {
            return result;
        }
        Direction direction = Direction.getFacing(pos.x - start.x, pos.y - start.y, pos.z - start.z);
        return BlockHitResult.createMissed(pos, direction, BlockPos.ofFloored((Position)pos));
    }

    @Inject(method={"tick"}, at={@At(value="HEAD")})
    public void tick(CallbackInfo param1) {
        EventPreTick v2 = new EventPreTick();
        EventBus.method3015(((Object)v2));
    }

    @Inject(method={"tick"}, at={@At(value="INVOKE", target="Lnet/minecraft/client/network/AbstractClientPlayerEntity;tick()V")})
    private void renderPostHook(CallbackInfo param1) {
        EventBus.method3015(((Object)new EventUpdate()));
    }

    @Inject(method={"tick"}, at={@At(value="TAIL", target="Lnet/minecraft/client/network/AbstractClientPlayerEntity;tick()V")})
    private void renderPreHook(CallbackInfo param1) {
        EventBus.method3015(((Object)new EventPostUpdate()));
    }

    @Inject(method={"tick"}, at={@At(value="RETURN")})
    private void minced$postTick(CallbackInfo param1) {
        EventBus.method3015(((Object)new EventPostTick()));
    }

    @Redirect(method={"tickMovementInput"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/network/ClientPlayerEntity;getPitch()F"))
    private float pitchAi(ClientPlayerEntity param1) {
        return RotationManager.method245();
    }

    @Redirect(method={"tickMovementInput"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/network/ClientPlayerEntity;getYaw()F"))
    private float yawAi(ClientPlayerEntity param1) {
        return RotationManager.method255();
    }

    @Redirect(method={"tickMovement"}, at=@At(value="INVOKE", target="Lnet/minecraft/util/PlayerInput;sprint()Z"))
    private boolean onSprintKeyPressed(PlayerInput param1) {
        EventSprint v2 = new EventSprint();
        EventBus.method3015(((Object)v2));
        if (v2.method2297()) {
            return true;
        }
        return param1.sprint();
    }

    @Redirect(method={"applyMovementSpeedFactors"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/network/ClientPlayerEntity;isUsingItem()Z"))
    private boolean onNoSlow(ClientPlayerEntity param1) {
        if (param1.isUsingItem() && !param1.hasVehicle()) {
            EventNoSlow v2 = new EventNoSlow();
            EventBus.method3015(((Object)v2));
            if (v2.method2297()) {
                return false;
            }
        }
        return param1.isUsingItem();
    }

    @Redirect(method={"isBlockedFromSprinting"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/network/ClientPlayerEntity;isUsingItem()Z"))
    private boolean redirectCanStartSprintIsUsingItem(ClientPlayerEntity param1) {
        EventNoSlow v2 = new EventNoSlow();
        EventBus.method3015(((Object)v2));
        if (v2.method2297()) {
            return false;
        }
        return param1.isUsingItem();
    }

    @Inject(method={"closeHandledScreen"}, at={@At(value="HEAD")}, cancellable=true)
    public void onCloseScreen(CallbackInfo param1) {
        ClientPlayerEntity v2 = (ClientPlayerEntity)(Object)this;
        int v3 = v2.currentScreenHandler.syncId;
        EventInventoryClose v4 = new EventInventoryClose(v3);
        EventBus.method3015(((Object)v4));
        if (v4.method2297()) {
            param1.cancel();
        }
    }

    @Inject(method={"sendMovementPackets"}, at={@At(value="HEAD")}, cancellable=true)
    public void onSendMovementPackets(CallbackInfo param1) {
        ClientPlayerEntity v2 = (ClientPlayerEntity)(Object)this;
        ClientPlayNetworkHandler v3 = v2.networkHandler;
        if (v3 instanceof ConnectionUtil) {
            NetworkPhase v5;
            PacketListener v4 = v3.getConnection() != null ? v3.getConnection().getPacketListener() : null;
            NetworkPhase networkPhase = v5 = v4 != null ? v4.getPhase() : null;
            if (v3.getPhase() != NetworkPhase.PLAY || v5 != NetworkPhase.PLAY) {
                param1.cancel();
                return;
            }
        }
        this.eventMotion = new EventMotion(v2.getX(), v2.getY(), v2.getZ(), v2.getYaw(), v2.getPitch(), v2.isOnGround(), v2.isSneaking(), v2.isSprinting());
        EventBus.method3015(((Object)this.eventMotion));
        if (this.eventMotion.method2297()) {
            param1.cancel();
        }
    }

    @Redirect(method={"sendMovementPackets"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/network/ClientPlayerEntity;getX()D"))
    private double redirectGetX(ClientPlayerEntity param1) {
        return this.eventMotion.method2518();
    }

    @Redirect(method={"sendMovementPackets"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/network/ClientPlayerEntity;getY()D"))
    private double redirectGetY(ClientPlayerEntity param1) {
        return this.eventMotion.method2508();
    }

    @Redirect(method={"sendMovementPackets"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/network/ClientPlayerEntity;getZ()D"))
    private double redirectGetZ(ClientPlayerEntity param1) {
        return this.eventMotion.method2513();
    }

    @Redirect(method={"sendMovementPackets"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/network/ClientPlayerEntity;getYaw()F"))
    private float redirectGetYaw(ClientPlayerEntity param1) {
        return this.eventMotion.method2514();
    }

    @Redirect(method={"sendMovementPackets"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/network/ClientPlayerEntity;getPitch()F"))
    private float redirectGetPitch(ClientPlayerEntity param1) {
        return this.eventMotion.method2515();
    }

    @Redirect(method={"sendMovementPackets"}, at=@At(value="INVOKE", target="Lnet/minecraft/client/network/ClientPlayerEntity;isOnGround()Z"))
    private boolean redirectIsOnGround(ClientPlayerEntity param1) {
        return this.eventMotion.method2516();
    }

    @Inject(method={"wouldCollideAt"}, at={@At(value="HEAD")}, cancellable=true)
    private void wouldCollideAt(BlockPos param1, CallbackInfoReturnable<Boolean> param2) {
        EventNoPush v3 = new EventNoPush(Block.Block);
        EventBus.method3015(((Object)v3));
        if (v3.method2297()) {
            param2.setReturnValue((Boolean)false);
        }
    }

}



