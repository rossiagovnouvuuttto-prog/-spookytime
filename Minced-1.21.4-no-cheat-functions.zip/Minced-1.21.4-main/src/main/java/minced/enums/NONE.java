package minced.enums;

public enum NONE {
    NONE,
    LITE_MODE,
    LITE_CATEGORY,
    LITE_SERVER,
    LITE120_MODE,
    LITE120_SERVER,
    CLASSIC_MODE,
    CLASSIC_SERVER;

    public static void method207() {
        // Kept for compatibility with the decompiled API. Enum constants are initialized by Java.
    }
}


