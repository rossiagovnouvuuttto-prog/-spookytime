package minced.enums;

public enum SOLO {
    SOLO,
    DUO,
    TRIO,
    CLAN,
    UNKNOWN;

    public static void method291() {
        // Kept for compatibility with the decompiled API. Enum constants are initialized by Java.
    }
}


