package minced.enums;

public enum NOTLOOTED {
    NOT_LOOTED,
    LOOTED,
    HAS_NAMETAG;

    public static void method77() {
        // Kept for compatibility with the decompiled API. Enum constants are initialized by Java.
    }
}


