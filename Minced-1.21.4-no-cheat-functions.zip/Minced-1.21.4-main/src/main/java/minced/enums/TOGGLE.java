package minced.enums;

public enum TOGGLE {
    TOGGLE,
    HOLD;

    public static void method206() {
        // Kept for compatibility with the decompiled API. Enum constants are initialized by Java.
    }
}


