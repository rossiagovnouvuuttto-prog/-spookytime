package minced.enums;

public enum fire {
    fire,
    bossbar,
    scoreboard,
    title,
    totem,
    hurttime,
    fishingrod,
    destroyparticles,
    rain,
    shadows,
    smoke,
    vignette,
    arrows,
    players,
    bad_effects,
    underwater_blur,
    container_background,
    lava,
    cameraclip,
    glowing;

    public static void method35() {
        // Kept for compatibility with the decompiled API. Enum constants are initialized by Java.
    }
}


