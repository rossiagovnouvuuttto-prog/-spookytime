package minced.enums;

public enum Block {
    Block,
    Water,
    Player,
    FishingRod;

    public static void method349() {
        // Kept for compatibility with the decompiled API. Enum constants are initialized by Java.
    }
}


