package minced.enums;

public enum PLACE_SAPLING {
    PLACE_SAPLING,
    GROW_TREE,
    BREAK_LEAVES,
    BREAK_LOGS;

    public static void method350() {
        // Kept for compatibility with the decompiled API. Enum constants are initialized by Java.
    }
}


