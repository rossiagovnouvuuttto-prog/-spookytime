package minced.enums;

public enum Eternity {
    Eternity(12883696, 14522096),
    Grass(10481814, 9892005),
    Reflection(9934576, 12490480),
    Gray(9477795, 8489615),
    Blooker(15775382, 15780246),
    PurpleLove(15767211, 15767190),
    Marimba(16551309, 0xF77E7E),
    Sky(9892073, 9883120),
    Blue(9873648, 10262256),
    Aurora(6222530, 7252223),
    Sakura(16747206, 16765404),
    Sunset(16752494, 16765286),
    Ocean(5032432, 4756975),
    Jade(6477475, 11006928),
    Ruby(16735354, 16747100),
    Frost(12443902, 10670847),
    Volt(14286693, 7143352),
    Cyberpunk(16722902, 58879),
    Arctic(8250367, 15399935),
    EmeraldNight(3462041, 959908),
    DeepOcean(49919, 3003583),
    Nebula(9133302, 15485081),
    Matrix(65382, 3800852),
    GoldenSand(14066234, 15909198),
    Garnet(12653087, 16741775),
    NorthernLights(3073702, 8141549),
    Volcano(16727296, 16748800),
    Crimson(14423100, 16739125),
    Amethyst(0x9966FF, 14239471),
    Mint(6225840, 9895904),
    Copper(12088115, 14711391),
    Lemon(16773749, 12124006),
    Plasma(0xFF00CC, 0x3333FF);

    public final int field1081;
    public final int field1082;

    Eternity(int firstColor, int secondColor) {
        this.field1081 = firstColor;
        this.field1082 = secondColor;
    }

    public static void method352() {
        // Kept for compatibility with the decompiled API. Enum constants are initialized by Java.
    }
}


