package minced.enums;

public enum IDLE1 {
    IDLE,
    SENT_HUB,
    USED_COMPASS,
    CLICKED_GRIEF_SURVIVAL;

    public static void method290() {
        // Kept for compatibility with the decompiled API. Enum constants are initialized by Java.
    }
}


