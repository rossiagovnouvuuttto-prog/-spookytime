package minced.enums;

public enum NONE1 {
    NONE,
    LITE,
    LITE120,
    CLASSIC;

    public static void method308() {
        // Kept for compatibility with the decompiled API. Enum constants are initialized by Java.
    }
}


