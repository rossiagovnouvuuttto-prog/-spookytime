package minced.enums;

public enum CameraRotationPhase {
    AIM,
    RESET,
    IDLE;

    public static void initialize() {
        // Kept for compatibility with the decompiled API. Enum constants are initialized by Java.
    }
}


