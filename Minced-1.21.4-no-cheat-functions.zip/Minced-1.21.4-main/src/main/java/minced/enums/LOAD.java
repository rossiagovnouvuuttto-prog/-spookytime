package minced.enums;

public enum LOAD {
    LOAD,
    UNLOAD,
    CHANGED;

    public static void method208() {
        // Kept for compatibility with the decompiled API. Enum constants are initialized by Java.
    }
}


