package minced.enums;

public enum FORWARD {
    FORWARD,
    BACKWARD;

    public static void method79() {
        // Kept for compatibility with the decompiled API. Enum constants are initialized by Java.
    }
}


