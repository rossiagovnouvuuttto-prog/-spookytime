package minced.enums;

public enum CRACKED {
    CRACKED,
    MICROSOFT;

    public static void method166() {
        // Kept for compatibility with the decompiled API. Enum constants are initialized by Java.
    }
}


