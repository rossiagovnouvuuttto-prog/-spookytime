package minced.enums;

public enum RECEIVE {
    RECEIVE,
    SEND;

    public static void method268() {
        // Kept for compatibility with the decompiled API. Enum constants are initialized by Java.
    }
}


