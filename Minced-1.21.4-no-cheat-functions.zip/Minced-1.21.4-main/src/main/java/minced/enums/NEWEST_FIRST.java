package minced.enums;

public enum NEWEST_FIRST {
    NEWEST_FIRST("Сначала новые"),
    OLDEST_FIRST("Сначала старые"),
    BY_NAME("По имени");

    public final String field805;

    NEWEST_FIRST(String name) {
        this.field805 = name;
    }

    public static void method258() {
        // Kept for compatibility with the decompiled API. Enum constants are initialized by Java.
    }
}


