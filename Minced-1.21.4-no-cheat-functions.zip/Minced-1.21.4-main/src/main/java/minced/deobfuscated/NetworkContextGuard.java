package minced.deobfuscated;

/** Scope used while the global client state is temporarily swapped for a bot connection. */
public final class NetworkContextGuard {
    private NetworkContextGuard() {
    }

    public abstract static class Scope implements AutoCloseable {
        public static final Scope NOOP = new Scope() {
            @Override
            public void close() {
            }
        };

        @Override
        public abstract void close();
    }
}
