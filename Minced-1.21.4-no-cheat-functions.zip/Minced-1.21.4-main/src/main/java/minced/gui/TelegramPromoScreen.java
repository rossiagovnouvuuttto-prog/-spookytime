package minced.gui;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.Util;

/** One-time startup promo displayed before the custom main menu. */
public final class TelegramPromoScreen extends Screen {
    private static final String CHANNEL_URL = "https://t.me/RakuzanClient";
    private static final long DISPLAY_TIME_MS = 10_000L;

    private long openedAtMs;
    private boolean finished;

    public TelegramPromoScreen() {
        super(Text.literal("Rakuzan Client"));
    }

    @Override
    protected void init() {
        super.init();
        if (openedAtMs == 0L) {
            openedAtMs = Util.getMeasuringTimeMs();
        }
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
        long elapsedMs = Util.getMeasuringTimeMs() - openedAtMs;
        if (elapsedMs >= DISPLAY_TIME_MS) {
            openMainMenu();
            return;
        }

        int centerX = width / 2;
        int centerY = height / 2;
        int panelHalfWidth = Math.min(220, Math.max(140, width / 2 - 24));
        int panelTop = centerY - 72;
        int panelBottom = centerY + 72;

        context.fill(0, 0, width, height, 0xFF050807);
        context.fill(centerX - panelHalfWidth - 1, panelTop - 1,
            centerX + panelHalfWidth + 1, panelBottom + 1, 0xFF26D9A4);
        context.fill(centerX - panelHalfWidth, panelTop,
            centerX + panelHalfWidth, panelBottom, 0xFF0D1512);

        context.drawCenteredTextWithShadow(textRenderer,
            Text.literal("Ещё больше портов в ТГК"), centerX, centerY - 43, 0xFFFFFFFF);
        context.drawCenteredTextWithShadow(textRenderer,
            Text.literal("Rakuzan Client"), centerX, centerY - 20, 0xFF26D9A4);

        boolean linkHovered = isLinkHovered(mouseX, mouseY, centerX, centerY + 7);
        int linkColor = linkHovered ? 0xFFFFFFFF : 0xFF53E6BB;
        int linkWidth = textRenderer.getWidth(CHANNEL_URL);
        context.fill(centerX - linkWidth / 2 - 6, centerY + 2,
            centerX + (linkWidth + 1) / 2 + 6, centerY + 17,
            linkHovered ? 0x5536E0AF : 0x3326D9A4);
        context.drawCenteredTextWithShadow(textRenderer,
            Text.literal(CHANNEL_URL), centerX, centerY + 6, linkColor);

        long remainingSeconds = Math.max(1L, (DISPLAY_TIME_MS - elapsedMs + 999L) / 1000L);
        context.drawCenteredTextWithShadow(textRenderer,
            Text.literal("Главное меню откроется через " + remainingSeconds + " сек."),
            centerX, centerY + 40, 0xFF9AA8A3);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        int centerX = width / 2;
        int linkY = height / 2 + 7;
        if (click.button() == 0 && isLinkHovered(click.x(), click.y(), centerX, linkY)) {
            Util.getOperatingSystem().open(CHANNEL_URL);
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    private boolean isLinkHovered(double mouseX, double mouseY, int centerX, int textY) {
        int linkWidth = textRenderer.getWidth(CHANNEL_URL);
        return mouseX >= centerX - linkWidth / 2.0 - 6.0
            && mouseX <= centerX + linkWidth / 2.0 + 6.0
            && mouseY >= textY - 4.0
            && mouseY <= textY + 11.0;
    }

    private void openMainMenu() {
        if (!finished && client != null) {
            finished = true;
            client.setScreen(new MainMenuScreen());
        }
    }
}
