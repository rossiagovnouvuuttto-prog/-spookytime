package minced.compat;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.systems.ProjectionType;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.Std140Builder;
import com.mojang.blaze3d.textures.GpuTextureView;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.Objects;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import minced.render.ImmediateRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.util.Identifier;
import org.joml.Matrix4f;
import org.joml.Matrix4fStack;

/** Compatibility state used by Minced's legacy immediate draw call sites. */
public final class RenderSystem {
    private static final Matrix4fStack MODEL_VIEW = new Matrix4fStack(32);
    private static final Matrix4f PROJECTION = new Matrix4f();
    private static GpuBuffer projectionBuffer;
    private static final Queue<Runnable> EARLY_RENDER_CALLS = new ConcurrentLinkedQueue<>();

    static {
        MODEL_VIEW.identity();
    }

    private RenderSystem() {
    }

    public static ShaderProgram setShader(ShaderProgramKey key) {
        replayEarlyRenderCalls();
        ShaderProgram program = Objects.requireNonNull(key).program();
        program.bind();
        return program;
    }

    public static void setShaderTexture(int slot, Identifier texture) {
        if (slot == 0) {
            ImmediateRenderer.setTexture(texture);
        }
    }

    public static void setShaderTexture(int slot, int texture) {
        if (texture == 0 && slot == 0) {
            ImmediateRenderer.clearTexture();
        }
    }

    public static void setShaderTexture(int slot, GpuTextureView texture) {
        if (slot == 0) ImmediateRenderer.setTexture(texture);
        else ImmediateRenderer.setTexture("Sampler" + slot, texture, com.mojang.blaze3d.textures.FilterMode.LINEAR);
    }

    public static void setShaderColor(float red, float green, float blue, float alpha) {
        ImmediateRenderer.setShaderColor(red, green, blue, alpha);
    }

    public static void enableBlend() { }
    public static void disableBlend() { }
    public static void defaultBlendFunc() { ImmediateRenderer.defaultBlend(); }
    public static void blendFunc(int source, int destination) { ImmediateRenderer.defaultBlend(); }
    public static void blendFunc(GlStateManager.SrcFactor source, GlStateManager.DstFactor destination) {
        ImmediateRenderer.setBlend(destination == GlStateManager.DstFactor.ONE ? BlendFunction.ADDITIVE : BlendFunction.TRANSLUCENT);
    }
    public static void blendFuncSeparate(int sourceRgb, int destinationRgb, int sourceAlpha, int destinationAlpha) {
        ImmediateRenderer.setBlend(destinationRgb == 1 ? BlendFunction.ADDITIVE : BlendFunction.TRANSLUCENT);
    }
    public static void blendFuncSeparate(GlStateManager.SrcFactor sourceRgb, GlStateManager.DstFactor destinationRgb,
                                         GlStateManager.SrcFactor sourceAlpha, GlStateManager.DstFactor destinationAlpha) {
        ImmediateRenderer.setBlend(destinationRgb == GlStateManager.DstFactor.ONE ? BlendFunction.ADDITIVE : BlendFunction.TRANSLUCENT);
    }

    public static void enableDepthTest() { ImmediateRenderer.enableDepthTest(); }
    public static void disableDepthTest() { ImmediateRenderer.disableDepthTest(); }
    public static void depthMask(boolean value) { ImmediateRenderer.depthMask(value); }
    public static void enableCull() { }
    public static void disableCull() { }
    public static void lineWidth(float width) { }
    public static void colorMask(boolean red, boolean green, boolean blue, boolean alpha) { }
    public static void viewport(int x, int y, int width, int height) { }
    public static void depthFunc(int function) { }
    public static void disableScissor() { ImmediateRenderer.setGuiScissor(null); }
    public static void activeTexture(int texture) { }
    public static void bindTexture(int texture) { }

    public static Matrix4fStack getModelViewStack() { return MODEL_VIEW; }
    public static Matrix4f getModelViewMatrix() { return new Matrix4f(MODEL_VIEW); }
    public static Matrix4f getProjectionMatrix() { return new Matrix4f(PROJECTION); }
    public static ProjectionType getProjectionType() { return com.mojang.blaze3d.systems.RenderSystem.getProjectionType(); }
    public static void setProjectionMatrix(Matrix4f matrix, ProjectionType type) {
        PROJECTION.set(matrix);
        ByteBuffer bytes = ByteBuffer.allocateDirect(64).order(ByteOrder.nativeOrder());
        Std140Builder.intoBuffer(bytes).putMat4f(matrix);
        // createBuffer reads the remaining range. Std140Builder leaves the
        // position at the end, so without flip() 1.21.11 sees an empty source.
        bytes.flip();
        GpuBuffer next = com.mojang.blaze3d.systems.RenderSystem.getDevice().createBuffer(
            () -> "Minced projection", GpuBuffer.USAGE_UNIFORM, bytes
        );
        com.mojang.blaze3d.systems.RenderSystem.setProjectionMatrix(next.slice(), type);
        if (projectionBuffer != null) {
            projectionBuffer.close();
        }
        projectionBuffer = next;
    }

    public static Tessellator renderThreadTesselator() { return Tessellator.getInstance(); }
    public static void assertOnRenderThread() { com.mojang.blaze3d.systems.RenderSystem.assertOnRenderThread(); }
    public static void recordRenderCall(Runnable action) {
        Objects.requireNonNull(action);
        if (com.mojang.blaze3d.systems.RenderSystem.tryGetDevice() == null) {
            EARLY_RENDER_CALLS.add(action);
        } else if (com.mojang.blaze3d.systems.RenderSystem.isOnRenderThread()) {
            action.run();
        } else {
            com.mojang.blaze3d.systems.RenderSystem.queueFencedTask(action);
        }
    }

    private static void replayEarlyRenderCalls() {
        if (com.mojang.blaze3d.systems.RenderSystem.tryGetDevice() == null
                || !com.mojang.blaze3d.systems.RenderSystem.isOnRenderThread()) {
            return;
        }
        Runnable action;
        while ((action = EARLY_RENDER_CALLS.poll()) != null) {
            action.run();
        }
    }
    public static float getShaderGameTime() { return (System.currentTimeMillis() % 1_200_000L) / 1_200_000.0f; }
}
