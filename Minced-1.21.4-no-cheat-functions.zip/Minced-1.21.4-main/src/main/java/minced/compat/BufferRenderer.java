package minced.compat;

import minced.render.ImmediateRenderer;
import net.minecraft.client.render.BuiltBuffer;

/** Routes removed BufferRenderer calls through Minced's explicit GPU bridge. */
public final class BufferRenderer {
    private BufferRenderer() {
    }

    public static void drawWithGlobalProgram(BuiltBuffer buffer) {
        ImmediateRenderer.draw(buffer);
    }

    public static void draw(BuiltBuffer buffer) {
        ImmediateRenderer.draw(buffer);
    }
}
