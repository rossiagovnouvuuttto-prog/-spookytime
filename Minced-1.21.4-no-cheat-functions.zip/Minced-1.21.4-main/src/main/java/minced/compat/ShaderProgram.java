package minced.compat;

import minced.render.ImmediateRenderer;
import minced.render.LegacyShaderProgram;

/** Legacy shader facade backed by an explicit 1.21.11 render pipeline. */
public final class ShaderProgram {
    private final LegacyShaderProgram delegate;

    ShaderProgram(LegacyShaderProgram delegate) {
        this.delegate = delegate;
    }

    void bind() {
        if (delegate == null) {
            ImmediateRenderer.clearShader();
        } else {
            delegate.bind();
        }
    }

    public GlUniform getUniform(String name) {
        if (delegate == null) {
            return null;
        }
        LegacyShaderProgram.UniformValue uniform = delegate.uniformOrNull(name);
        return uniform == null ? null : new GlUniform(uniform);
    }

    LegacyShaderProgram delegate() {
        return delegate;
    }
}
