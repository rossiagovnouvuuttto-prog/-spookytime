package minced.compat;

import com.mojang.blaze3d.textures.GpuTexture;

/** Small state facade retained for decompiled 1.21.4 call sites. */
public final class GlStateManager {
    public enum SrcFactor { ZERO, ONE, SRC_ALPHA }
    public enum DstFactor { ONE, ONE_MINUS_SRC_ALPHA }

    private GlStateManager() {
    }

    public static void _enableBlend() { RenderSystem.enableBlend(); }
    public static void _disableBlend() { RenderSystem.disableBlend(); }
    public static void _blendFunc(int source, int destination) { RenderSystem.blendFunc(source, destination); }
    public static void _depthMask(boolean value) { RenderSystem.depthMask(value); }
    public static void _disableDepthTest() { RenderSystem.disableDepthTest(); }
    public static void _colorMask(boolean red, boolean green, boolean blue, boolean alpha) { RenderSystem.colorMask(red, green, blue, alpha); }
    public static void _viewport(int x, int y, int width, int height) { RenderSystem.viewport(x, y, width, height); }
    public static void _clearColor(float red, float green, float blue, float alpha) { }
    public static void _clear(int mask) { }
    public static void _bindTexture(int texture) { }
    public static void _bindTexture(GpuTexture texture) {
        if (texture != null) {
            RenderSystem.setShaderTexture(0, com.mojang.blaze3d.systems.RenderSystem.getDevice().createTextureView(texture));
        }
    }
    public static int _genTexture() { return 0; }
    public static void _texParameter(int target, int parameter, int value) { }
    public static void _activeTexture(int texture) { }
    public static int _getActiveTexture() { return 0; }
}
